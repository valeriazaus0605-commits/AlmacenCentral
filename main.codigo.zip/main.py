import os
import sys

# Importación de todas las piezas desarrolladas por el equipo
from modulos.pedidos import registrar_cliente, buscar_cliente, registrar_pedido, buscar_pedido
from modulos.stock import agregar_stock, ver_inventario, cargar_productos, guardar_productos
from modulos.despacho import asignar_despacho, actualizar_estado_nuevo
from modulos.reportes import obtener_alertas_reabastecimiento, calcular_porcentaje_pedidos_retrasados, listar_pedidos_por_estado, calcular_ingresos_totales_acumulados

# Calculamos la ruta absoluta base para que se conecte de forma idéntica
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RUTA_PRODUCTOS = os.path.join(BASE_DIR, "datos", "productos.json")

def menu_principal():
    # Inicialización del catálogo base si es la primera vez que se corre
    if not os.path.exists(RUTA_PRODUCTOS):
        productos_base = {
            "PROD01": {"nombre": "Cajas de Clavos 2 pulgadas", "precio": 15.50, "cantidad": 50},
            "PROD02": {"nombre": "Martillo de Carpintero Pro", "precio": 42.00, "cantidad": 12},
            "PROD03": {"nombre": "Cinta Métrica 5m Heavy Duty", "precio": 8.50, "cantidad": 100},
            "PROD04": {"nombre": "Taladro Inalámbrico 20V", "precio": 289.90, "cantidad": 4},
            "PROD05": {"nombre": "Juego de Destornilladores x6", "precio": 34.50, "cantidad": 32},
            "PROD06": {"nombre": "Alicate de Presión 10 pulgadas", "precio": 28.00, "cantidad": 3},
            "PROD07": {"nombre": "Cinta Aislante Negra 20m", "precio": 4.20, "cantidad": 150},
            "PROD08": {"nombre": "Espuma Expansiva Poliuretano", "precio": 19.90, "cantidad": 13},
            "PROD09": {"nombre": "Casco de Seguridad Amarillo", "precio": 14.00, "cantidad": 26},
            "PROD10": {"nombre": "Amoladora Angular 4.5 pulg", "precio": 145.00, "cantidad": 15}
        }
        guardar_productos(productos_base)

    while True:
        print("\n=============================================")
        print("     SISTEMA INTEGRAL 'EL ALMACÉN CENTRAL'     ")
        print("=============================================")
        print("1. GESTIÓN DE CLIENTES Y VENTAS")
        print("2. CONTROL DE INVENTARIO Y STOCK")
        print("3. LOGÍSTICA Y DESPACHOS")
        print("4. REPORTES E INDICADORES GERENCIALES")
        print("5. SALIR DEL SISTEMA")
        print("=============================================")

        try:
            opcion = int(input("Seleccione un módulo (1-5): "))
        except ValueError:
            continue

        if opcion == 1:
            while True:
                print("\n--> [SUBMENÚ] GESTIÓN DE CLIENTES Y VENTAS")
                print("1.1 Registrar Cliente\n1.2 Crear Pedido Nuevo\n1.3 Buscar Pedido por ID\n1.4 Volver")
                sub_op = input("Seleccione opción: ").strip()
                if sub_op in ["1.1", "1"]:
                    registrar_cliente(input("DNI/RUC: "), input("Nombre: "), input("Telf: "), input("Dir: "))
                elif sub_op in ["1.2", "2"]:
                    dni = input("DNI del cliente: ")
                    cl = buscar_cliente(dni)
                    if not cl: 
                        print("[!] Cliente no encontrado. Regístrelo en la opción 1.1")
                        continue
                    carrito = []
                    db = cargar_productos()
                    while True:
                        ver_inventario()
                        id_p = input("\nCódigo de producto (o escriba 'fin' para facturar): ").strip().upper()
                        if id_p.lower() == 'fin': break
                        if id_p not in db: continue
                        cant = int(input("Cantidad: "))
                        carrito.append({"producto": id_p, "cantidad": cant, "precio_unitario": db[id_p]["precio"]})
                    if carrito: registrar_pedido(dni, carrito)
                elif sub_op in ["1.3", "3"]:
                    print(buscar_pedido(input("ID Pedido: ").strip().upper()))
                elif sub_op in ["1.4", "4"]: break
        elif opcion == 2:
            while True:
                print("\n--> [SUBMENÚ] CONTROL DE INVENTARIO Y STOCK")
                print("2.1 Agregar Stock\n2.2 Ver Catálogo\n2.3 Volver")
                sub_op = input("Seleccione opción: ").strip()
                if sub_op in ["2.1", "1"]: agregar_stock(input("Código: "), int(input("Cantidad: ")))
                elif sub_op in ["2.2", "2"]: ver_inventario()
                elif sub_op in ["2.3", "3"]: break
        elif opcion == 3:
            while True:
                print("\n--> [SUBMENÚ] LOGÍSTICA Y DESPACHOS")
                print("3.1 Asignar Repartidor\n3.2 Cambiar Estado de Envío\n3.3 Volver")
                sub_op = input("Seleccione opción: ").strip()
                if sub_op in ["3.1", "1"]: print(asignar_despacho(input("ID Pedido: "), input("Repartidor: ")))
                elif sub_op in ["3.2", "2"]:
                    id_p = input("ID Pedido: ")
                    est = input("1. Entregado\n2. Retrasado\n3. No Entregado\nOpción: ")
                    mapeo = {"1": "Entregado", "2": "Retrasado", "3": "No Entregado"}
                    if est in mapeo: print(actualizar_estado_nuevo(id_p, mapeo[est]))
                elif sub_op in ["3.3", "3"]: break
        elif opcion == 4:
            while True:
                print("\n--> [SUBMENÚ] REPORTES E INDICADORES GERENCIALES")
                print("4.1 Alertas Stock\n4.2 KPI Retrasos\n4.3 Filtrar por Estado\n4.4 Volver")
                sub_op = input("Seleccione opción: ").strip()
                if sub_op in ["4.1", "1"]: obtener_alertas_reabastecimiento(int(input("Umbral: ")))
                elif sub_op in ["4.2", "2"]: calcular_porcentaje_pedidos_retrasados()
                elif sub_op in ["4.3", "3"]: listar_pedidos_por_estado(input("Estado: "))
                elif sub_op in ["4.4", "4"]: break
        elif opcion == 5: 
            print("\nCerrando sistema... ¡Hasta luego!")
            break

if __name__ == "__main__":
    menu_principal()
    